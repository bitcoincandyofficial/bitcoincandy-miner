#!/bin/bash
./miner --algo 144_5 --pers CandyPoW --server pool.cdy.one --port 3857 --user CSZnk6KoMoEwHmveF3KcyRfEWsZfZ3dgEU.MyWorker --pass x
