./cdyminer64
