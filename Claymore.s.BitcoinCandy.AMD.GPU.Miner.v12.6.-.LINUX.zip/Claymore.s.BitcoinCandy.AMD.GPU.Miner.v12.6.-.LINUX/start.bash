./zecminer64
